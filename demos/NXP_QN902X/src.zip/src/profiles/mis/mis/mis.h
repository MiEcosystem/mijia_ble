/**
 ****************************************************************************************
 *
 * @file mis.h
 *
 * @brief Header file - Mible Profile Server.
 *
 * Copyright (C) RivieraWaves 2009-2013
 *
 * $Rev: $
 *
 ****************************************************************************************
 */

#ifndef MIS_H_
#define MIS_H_

/**
 ****************************************************************************************
 * @addtogroup Mible Profile Server
 * @ingroup MIS
 * @brief Mible Profile Server
 * @{
 ****************************************************************************************
 */

/*
 * INCLUDE FILES
 ****************************************************************************************
 */

#include "mis_common.h"

#if (BLE_MIS_SERVER)

#include "prf_types.h"

/*
 * ENUMERATIONS
 ****************************************************************************************
 */

/// Mible Service Attributes
enum mible_att_list
{
    MIBLE_IDX_SVC,

    MIBLE_IDX_TOKEN_CHAR,
    MIBLE_IDX_TOKEN_VAL,
    MIBLE_IDX_TOKEN_NTF_CFG,
    
    MIBLE_IDX_PRODUCT_ID_CHAR,
    MIBLE_IDX_PRODUCT_ID_VAL,

    MIBLE_IDX_VERSION_CHAR,
    MIBLE_IDX_VERSION_VAL,

    MIBLE_IDX_WIFI_CFG_CHAR,
    MIBLE_IDX_WIFI_CFG_VAL,
    MIBLE_IDX_WIFI_CFG_NTF_CFG,
    
    MIBLE_IDX_AUTHEN_CHAR,
    MIBLE_IDX_AUTHEN_VAL,

    MIBLE_IDX_DID_CHAR,
    MIBLE_IDX_DID_VAL,
    
    MIBLE_IDX_BEACONKEY_CHAR,
    MIBLE_IDX_BEACONKEY_VAL,

    MIS_IDX_NB,
};

/*
 * STRUCTURES
 ****************************************************************************************
 */

/// Mible Profile Server. Environment variable
struct mis_env_tag
{
    /// Mible Start Handle
    uint16_t mis_shdl; 
};

/// Mible Profile Server Instance Environment variable
struct mis_idx_env_tag
{
    /// Connection Info
    struct prf_con_info con_info;

    /// Operation
    uint8_t operation;
};

/*
 * GLOBAL VARIABLE DECLARATIONS
 ****************************************************************************************
 */

extern const struct atts_desc mis_att_db[MIS_IDX_NB];

/// Environment common to each task instance
extern struct mis_env_tag mis_env;
/// Pool of tips environments
extern struct mis_idx_env_tag **mis_idx_envs;

/*
 * MACROS
 * **************************************************************************************
 */


/*
 * FUNCTION DECLARATIONS
 ****************************************************************************************
 */

/**
 ****************************************************************************************
 * @brief Initialization of the MIS module.
 * This function performs all the initializations of the MIS module.
 ****************************************************************************************
 */
void mis_init(void);


/**
 ****************************************************************************************
 * @brief Send an MIS_CMP_EVT message to a requester.
 *
 * @param[in] src_id        Source ID of the message (instance of TASK_MIS)
 * @param[in] dest_id       Destination ID of the message
 * @param[in] operation     Code of the completed operation
 * @param[in] status        Status of the request
 ****************************************************************************************
 */
void mis_send_cmp_evt(ke_task_id_t src_id, ke_task_id_t dest_id, uint16_t conhdl,
                       uint8_t operation, uint8_t status);

/**
 ****************************************************************************************
 * @brief Disable actions grouped in getting back to IDLE and sending configuration to requester task
 ****************************************************************************************
 */
void mis_disable(struct mis_idx_env_tag *mis_idx_env);

#endif //(BLE_MIS_SERVER)

/// @} MIS

#endif //(MIS_H_)
