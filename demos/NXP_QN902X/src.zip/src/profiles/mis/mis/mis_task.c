/**
 ****************************************************************************************
 *
 * @file mis_task.c
 *
 * @brief Mible Profile Server Task implementation.
 *
 * Copyright (C) RivieraWaves 2009-2013
 *
 * $ Rev: $
 *
 ****************************************************************************************
 */

/**
 ****************************************************************************************
 * @addtogroup MISTASK
 * @{
 ****************************************************************************************
 */

/*
 * INCLUDE FILES
 ****************************************************************************************
 */

#include "app_config.h"

#if (BLE_MIS_SERVER)

#include "gap.h"
#include "gatt_task.h"
#include "atts_util.h"
#include "mis.h"
#include "mis_task.h"

#include "prf_utils.h"
#include "prf_types.h"

#include "mible_type.h"

/*
 * DEFINES
 ****************************************************************************************
 */

#define MIS_DB_CONFIG_MASK         0xFFFF// chx (0x1FFF)

/*
 * LOCAL FUNCTIONS DEFINITIONS
 ****************************************************************************************
 */


/**
 ****************************************************************************************
 * @brief Handles reception of the @ref MIS_CREATE_DB_REQ message.
 * @param[in] msgid Id of the message received.
 * @param[in] param Pointer to the parameters of the message.
 * @param[in] dest_id ID of the receiving task instance.
 * @param[in] src_id ID of the sending task instance.
 * @return If the message was consumed or not.
 ****************************************************************************************
 */
static int mis_create_db_req_handler(ke_msg_id_t const msgid,
                                      struct mis_create_db_req *param,
                                      ke_task_id_t const dest_id,
                                      ke_task_id_t const src_id)
{
    // Service Configuration Flag - All attributes have to be added in the database
    uint16_t cfg_flag = MIS_DB_CONFIG_MASK;
    // Database Creation Status
    uint8_t status;
    // Counter
    uint8_t counter;

    // Check if an MIS has already been added in the database
    if (ke_state_get(TASK_MIS) == MIS_DISABLED)
    {
        // Add service in the database
        status = atts_svc_create_db(&mis_env.mis_shdl, (uint8_t *)&cfg_flag, MIS_IDX_NB, NULL,
                                    dest_id, &mis_att_db[0]);

        // Go to Idle State
        if (status == ATT_ERR_NO_ERROR)
        {
            // Disable MIS
            attsdb_svc_set_permission(mis_env.mis_shdl, PERM(SVC, DISABLE));

            for (counter = 0; counter < MIS_IDX_MAX; counter++)
            {
                // If we are here, database has been fulfilled with success, go to idle state
                ke_state_set(KE_BUILD_ID(TASK_MIS, counter), MIS_IDLE);
            }
        } 
    }
    else
    {
        // Request is disallowed, an ANS has already been added
        status = PRF_ERR_REQ_DISALLOWED;
    }

    // Send response to application
    mis_send_cmp_evt(TASK_MIS, src_id, GAP_INVALID_CONHDL, MIS_CREATE_DB_OP_CODE, status);

    return (KE_MSG_CONSUMED);
}

/**
 ****************************************************************************************
 * @brief Handles reception of the @ref MIS_ENABLE_REQ message.
 * @param[in] msgid Id of the message received.
 * @param[in] param Pointer to the parameters of the message.
 * @param[in] dest_id ID of the receiving task instance.
 * @param[in] src_id ID of the sending task instance.
 * @return If the message was consumed or not.
 ****************************************************************************************
 */
static int mis_enable_req_handler(ke_msg_id_t const msgid,
                                   struct mis_enable_req *param,
                                   ke_task_id_t const dest_id,
                                   ke_task_id_t const src_id)
{
    // Mible Profile Server Role Task Index Environment
    struct mis_idx_env_tag *mis_idx_env = NULL;
    // Connection Information structure
    struct prf_con_info con_info;
    // Status
    uint8_t status = PRF_ERR_OK;
    // Message status
    uint8_t msg_status = KE_MSG_CONSUMED;

    // Check if the provided connection handle is valid
    if (gap_get_rec_idx(param->conhdl) != GAP_INVALID_CONIDX)
    {
        // Fill the Connection Information structure
        con_info.conhdl = param->conhdl;
        con_info.prf_id = dest_id;
        con_info.appid  = src_id;

        // Add an environment for the provided device
        status = PRF_CLIENT_ENABLE(con_info, param, mis_idx);
    }
    else
    {
        status = PRF_ERR_REQ_DISALLOWED;
    }

    if (status == PRF_ERR_OK)
    {
        // Get the newly created environment
        mis_idx_env = PRF_CLIENT_GET_ENV(dest_id, mis_idx);

        // Keep the Connection Information structure content
        memcpy(&mis_idx_env->con_info, &con_info, sizeof(struct prf_con_info));

        if (param->con_type == PRF_CON_DISCOVERY)
        {
        }
        else        // PRF_CON_NORMAL (Bonded peer device)
        {
        }

        // Enable MIS
        attsdb_svc_set_permission(mis_env.mis_shdl, param->sec_lvl);

        // Go to Connected State
        ke_state_set(dest_id, MIS_CONNECTED);

        // Send a complete event status to the application
        mis_send_cmp_evt(mis_idx_env->con_info.prf_id, mis_idx_env->con_info.appid, mis_idx_env->con_info.conhdl,
                          MIS_ENABLE_OP_CODE, PRF_ERR_OK);
    }
    else if (status == PRF_ERR_FEATURE_NOT_SUPPORTED)
    {
        // The message has been forwarded to another task id.
        msg_status = KE_MSG_NO_FREE;
    }
    else
    {
        // The request is disallowed (profile already enabled for this connection, or not enough memory, ...)
        mis_send_cmp_evt(dest_id, src_id, param->conhdl, MIS_ENABLE_OP_CODE, PRF_ERR_REQ_DISALLOWED);
    }

    return (int)msg_status;
}



/**
 ****************************************************************************************
 * @brief Handles @ref GATT_NOTIFY_CMP_EVT message.
 * @param[in] msgid     Id of the message received.
 * @param[in] param     Pointer to the parameters of the message.
 * @param[in] dest_id   ID of the receiving task instance
 * @param[in] src_id    ID of the sending task instance.
 * @return If the message was consumed or not.
 ****************************************************************************************
 */
static int gatt_notify_cmp_evt_handler(ke_msg_id_t const msgid,
                                       struct gatt_notify_cmp_evt const *param,
                                       ke_task_id_t const dest_id,
                                       ke_task_id_t const src_id)
{
    // Get the address of the environment
    struct mis_idx_env_tag *mis_idx_env = PRF_CLIENT_GET_ENV(dest_id, mis_idx);

#if (QN_MULTI_NOTIFICATION_IN_ONE_EVENT)  
    if(param->status == GATT_NOTIFY_GET_DATA)
        return (KE_MSG_CONSUMED);        
#endif

    if (mis_idx_env != NULL)
    {
        // Send a complete event status to the application
        mis_send_cmp_evt(mis_idx_env->con_info.prf_id, mis_idx_env->con_info.appid, mis_idx_env->con_info.conhdl,
                          mis_idx_env->operation, param->status);
    }
    // else ignore the message

    return (KE_MSG_CONSUMED);
}

/**
 ****************************************************************************************
 * @brief Handles reception of the @ref GATT_WRITE_CMD_IND message.
 * @param[in] msgid Id of the message received (probably unused).
 * @param[in] param Pointer to the parameters of the message.
 * @param[in] dest_id ID of the receiving task instance (probably unused).
 * @param[in] src_id ID of the sending task instance.
 * @return If the message was consumed or not.
 ****************************************************************************************
 */
extern void app_task_msg_hdl(ke_msg_id_t const msgid, void const *param);
static int gatt_write_cmd_ind_handler(ke_msg_id_t const msgid,
                                      struct gatt_write_cmd_ind const *param,
                                      ke_task_id_t const dest_id,
                                      ke_task_id_t const src_id)
{
    // Get the address of the environment
    struct mis_idx_env_tag *mis_idx_env = PRF_CLIENT_GET_ENV(KE_BUILD_ID(dest_id, gap_get_rec_idx(param->conhdl)), mis_idx);

    // Check if the connection exists
    if (mis_idx_env != NULL)
    {
        // Status
        uint8_t status = PRF_ERR_OK;

        /*
         * ---------------------------------------------------------------------------------------------
         * Client Characteristic Configuration Descriptor Value - Write
         * ---------------------------------------------------------------------------------------------
         */
        if ((param->handle == (mis_env.mis_shdl + MIBLE_IDX_TOKEN_NTF_CFG)) ||
            (param->handle == (mis_env.mis_shdl + MIBLE_IDX_WIFI_CFG_NTF_CFG)))
        {
            // Received configuration value
            uint16_t ntf_cfg = co_read16p(&param->value[0]);

            if (ntf_cfg <= PRF_CLI_START_NTF)
            {
                // Set the value of the Alert Status Client Characteristic Configuration Descriptor (Readable)
                attsdb_att_set_value(param->handle, sizeof(uint16_t), (uint8_t *)&ntf_cfg);
                QPRINTF("[attsdb_att_set_value]\r\n");
            }
            else
            {
                status = PRF_APP_ERROR;
            }
        }
        /*
         * ---------------------------------------------------------------------------------------------
         * Control Point Characteristic Value - Write
         * ---------------------------------------------------------------------------------------------
         */
        else if ((param->handle == (mis_env.mis_shdl + MIBLE_IDX_AUTHEN_VAL))
            || (param->handle == (mis_env.mis_shdl + MIBLE_IDX_TOKEN_VAL))
            || (param->handle == (mis_env.mis_shdl + MIBLE_IDX_WIFI_CFG_VAL))
            || (param->handle == (mis_env.mis_shdl + MIBLE_IDX_DID_VAL)))
        {
            app_task_msg_hdl(msgid, param);
        }
        else
        {
            //ASSERT_ERR(0);
        }

        // Send write response
        atts_write_rsp_send(param->conhdl, param->handle, status);
    }

    // else ignore the message


    return (KE_MSG_CONSUMED);
}

/**
 ****************************************************************************************
 * @brief Disconnection indication to MIS.
 * @param[in] msgid     Id of the message received.
 * @param[in] param     Pointer to the parameters of the message.
 * @param[in] dest_id   ID of the receiving task instance
 * @param[in] src_id    ID of the sending task instance.
 * @return If the message was consumed or not.
 ****************************************************************************************
 */
static int gap_discon_cmp_evt_handler(ke_msg_id_t const msgid,
                                      struct gap_discon_cmp_evt const *param,
                                      ke_task_id_t const dest_id,
                                      ke_task_id_t const src_id)
{
    // Get the address of the environment
    struct mis_idx_env_tag *mis_idx_env = PRF_CLIENT_GET_ENV(dest_id, mis_idx);

    // Check if the profile was enabled for this connection
    if (mis_idx_env != NULL)
    {
        mis_disable(mis_idx_env);
    }
    // else ignore the message

    return (KE_MSG_CONSUMED);
}

/*
 * GLOBAL VARIABLE DEFINITIONS
 ****************************************************************************************
 */

/// Specifies the default message handlers
const struct ke_msg_handler mis_default_state[] =
{
    {MIS_CREATE_DB_REQ,           (ke_msg_func_t)mis_create_db_req_handler},
    {MIS_ENABLE_REQ,              (ke_msg_func_t)mis_enable_req_handler},

    {GATT_NOTIFY_CMP_EVT,          (ke_msg_func_t)gatt_notify_cmp_evt_handler},
    {GATT_WRITE_CMD_IND,           (ke_msg_func_t)gatt_write_cmd_ind_handler},

    {GAP_DISCON_CMP_EVT,           (ke_msg_func_t)gap_discon_cmp_evt_handler},
};

// Specifies the message handler structure for every input state.
const struct ke_state_handler mis_state_handler[MIS_STATE_MAX] =
{
    [MIS_DISABLED]    = KE_STATE_HANDLER_NONE,
    [MIS_IDLE]        = KE_STATE_HANDLER_NONE,
    [MIS_CONNECTED]   = KE_STATE_HANDLER_NONE,
    [MIS_BUSY]        = KE_STATE_HANDLER_NONE,
};

// Specifies the message handlers that are common to all states.
const struct ke_state_handler mis_default_handler = KE_STATE_HANDLER(mis_default_state);

// Defines the place holder for the states of all the task instances.
ke_state_t mis_state[MIS_IDX_MAX];

// Register MIS TASK into kernel
void task_mis_desc_register(void)
{
    struct ke_task_desc task_mis_desc;
    
    task_mis_desc.state_handler = mis_state_handler;
    task_mis_desc.default_handler= &mis_default_handler;
    task_mis_desc.state = mis_state;
    task_mis_desc.state_max = MIS_STATE_MAX;
    task_mis_desc.idx_max = MIS_IDX_MAX;

    task_desc_register(TASK_MIS, task_mis_desc);
}
#endif //(BLE_MIS_SERVER)

/// @} MISTASK
