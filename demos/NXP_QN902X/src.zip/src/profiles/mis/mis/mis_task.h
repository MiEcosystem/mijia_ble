/**
 ****************************************************************************************
 *
 * @file mis_task.h
 *
 * @brief Header file - MISTASK.
 *
 * Copyright (C) RivieraWaves 2009-2013
 *
 * $ Rev: $
 *
 ****************************************************************************************
 */

#ifndef MIS_TASK_H_
#define MIS_TASK_H_

/// @cond

/**
 ****************************************************************************************
 * @addtogroup MISTASK Task
 * @ingroup MIS
 * @brief MIS Profile Server Task
 * @{
 ****************************************************************************************
 */

/*
 * INCLUDE FILES
 ****************************************************************************************
 */

#if (BLE_MIS_SERVER)

#include "ke_task.h"
#include "mis.h"

/*
 * DEFINES
 ****************************************************************************************
 */

/// Maximal number of Mible Server task instances
#define MIS_IDX_MAX        (BLE_CONNECTION_MAX)

/*
 * ENUMERATIONS
 ****************************************************************************************
 */

/// Possible states of the MIS task
enum mis_states
{
    /// Disabled state
    MIS_DISABLED,
    /// Idle state
    MIS_IDLE,
    /// Connected state
    MIS_CONNECTED,
    /// Busy state
    MIS_BUSY,

    /// Number of defined states.
    MIS_STATE_MAX
};

/// Messages for Mible Profile Server
enum mis_msg_ids
{
    /// Database Creation
    MIS_CREATE_DB_REQ = KE_FIRST_MSG(TASK_MIS),

    /// Start the Mible Profile Server Role
    MIS_ENABLE_REQ,
    /// Disable confirmation with configuration to save after profile disabled
    MIS_DISABLE_IND,

    /// Complete Event Information
    MIS_CMP_EVT,
};

/// Operation Codes
enum mis_op_codes
{
    MIS_RESERVED_OP_CODE              = 0x00,

    /// Database Creation Procedure
    MIS_CREATE_DB_OP_CODE,
    /// Enable Procedure
    MIS_ENABLE_OP_CODE,
};

/*
 * STRUCTURES
 ****************************************************************************************
 */

/// Parameters of the @ref MIS_CREATE_DB_REQ message
struct mis_create_db_req
{
    uint8_t parm;
};

/// Parameters of the @ref MIS_ENABLE_REQ message
struct mis_enable_req
{
    /// Connection handle
    uint16_t conhdl;
    /// Security Level
    uint8_t sec_lvl;
    /// Type of connection
    uint8_t con_type;
};


/// @endcond

/**
 ****************************************************************************************
 * @addtogroup APP_MIS_TASK
 * @{
 ****************************************************************************************
 */

///Parameters of the @ref MIS_DISABLE_IND message
struct mis_disable_ind
{
    /// Connection Handle
    uint16_t conhdl;
};


///Parameters of the @ref MIS_CMP_EVT message
struct mis_cmp_evt
{
    /// Connection Handle
    uint16_t conhdl;
    /// Operation
    uint8_t operation;
    /// Status
    uint8_t status;
};
/// @} APP_MIS_TASK

/// @cond

/*
 * TASK DESCRIPTOR DECLARATIONS
 ****************************************************************************************
 */

extern const struct ke_state_handler mis_state_handler[MIS_STATE_MAX];
extern const struct ke_state_handler mis_default_handler;
extern ke_state_t mis_state[MIS_IDX_MAX];

extern void task_mis_desc_register(void);
#endif //(BLE_MIS_SERVER)

/// @} MISTASK
/// @endcond
#endif //(MIS_TASK_H_)
