/**
 ****************************************************************************************
 *
 * @file mis.c
 *
 * @brief Mible Profile Server implementation.
 *
 * Copyright (C) RivieraWaves 2009-2013
 *
 * $ Rev: $
 *
 ****************************************************************************************
 */

/**
 ****************************************************************************************
 * @addtogroup MIS
 * @{
 ****************************************************************************************
 */

/*
 * INCLUDE FILES
 ****************************************************************************************
 */

#include "app_config.h"

#if (BLE_MIS_SERVER)

#include "atts_util.h"
#include "mis.h"
#include "mis_task.h"
#include "mis_common.h"
#include "prf_utils.h"
#include "prf_types.h"

/*
 * MIBLE ATTRIBUTES
 ****************************************************************************************
 */
#define MIBLE_SRV_UUID                          0xFE95//{0x95,0xFE}  
#define MIBLE_STD_CHAR_NUM                      7
#define MIBLE_CHAR_UUID_TOKEN                   0x0001
#define MIBLE_CHAR_UUID_PRODUCTID               0x0002
#define MIBLE_CHAR_UUID_VERSION                 0x0004
#define MIBLE_CHAR_UUID_WIFICFG                 0x0005
#define MIBLE_CHAR_UUID_AUTHENTICATION          0x0010
#define MIBLE_CHAR_UUID_DID                     0x0013
#define MIBLE_CHAR_UUID_BEACONKEY               0x0014
#define MIBLE_CHAR_UUID_DEVICE                  0x0015
#define MIBLE_CHAR_UUID_SECURE                  0x0016

#define MIBLE_CHAR_LEN_TOKEN                    12
#define MIBLE_CHAR_LEN_PRODUCTID                2
#define MIBLE_CHAR_LEN_VERSION                  10
#define MIBLE_CHAR_LEN_WIFICFG                  20
#define MIBLE_CHAR_LEN_AUTHENTICATION           4
#define MIBLE_CHAR_LEN_DID                      20
#define MIBLE_CHAR_LEN_BEACONKEY                12
#define MIBLE_CHAR_LEN_DEVICE                   20
#define MIBLE_CHAR_LEN_SECURE                   20

/// Mible Service
const atts_svc_desc_t mible_svc                          = MIBLE_SRV_UUID;

///
const struct atts_char_desc mible_token_char             = ATTS_CHAR(ATT_CHAR_PROP_NTF | ATT_CHAR_PROP_WR,
                                                                        0,
                                                                        MIBLE_CHAR_UUID_TOKEN);
///
const struct atts_char_desc mible_product_id_char    = ATTS_CHAR(ATT_CHAR_PROP_RD,
                                                                        0,
                                                                        MIBLE_CHAR_UUID_PRODUCTID);
///
const struct atts_char_desc mible_version_char = ATTS_CHAR(ATT_CHAR_PROP_RD,
                                                                        0,
                                                                        MIBLE_CHAR_UUID_VERSION);
///
const struct atts_char_desc mible_wifi_cfg_char   = ATTS_CHAR(ATT_CHAR_PROP_NTF | ATT_CHAR_PROP_WR,
                                                                        0,
                                                                        MIBLE_CHAR_UUID_WIFICFG);
/// Mible Service - authentication Characteristic
const struct atts_char_desc mible_authen_char = ATTS_CHAR(ATT_CHAR_PROP_WR,
                                                             0, //No attribute table for MIBLE
                                                             MIBLE_CHAR_UUID_AUTHENTICATION);
/// Mible Service - DID Characteristic
const struct atts_char_desc mible_did_char = ATTS_CHAR(ATT_CHAR_PROP_RD | ATT_CHAR_PROP_WR,
                                                             0, //No attribute table for MIBLE
                                                             MIBLE_CHAR_UUID_DID);
/// Mible Service - Beaconkey Characteristic
const struct atts_char_desc mible_beaconkey_char = ATTS_CHAR(ATT_CHAR_PROP_RD,
                                                             0, //No attribute table for MIBLE
                                                             MIBLE_CHAR_UUID_BEACONKEY);

/*
 * MIBLE DATABASE
 ****************************************************************************************
 */

/// Full MIBLE Database Description - Used to add attributes into the database
const struct atts_desc mis_att_db[MIS_IDX_NB]   =
{
    /// Mible Service Declaration
    [MIBLE_IDX_SVC]                             =   {ATT_DECL_PRIMARY_SERVICE, PERM(RD, ENABLE), sizeof(mible_svc),
                                                 sizeof(mible_svc), (uint8_t *)&mible_svc},

    /// Token Characteristic Declaration
    [MIBLE_IDX_TOKEN_CHAR]                      =   {ATT_DECL_CHARACTERISTIC, PERM(RD, ENABLE), sizeof(mible_token_char),
                                                    sizeof(mible_token_char), (uint8_t *)&mible_token_char},
    /// Token Characteristic Value
    [MIBLE_IDX_TOKEN_VAL]                       =   {MIBLE_CHAR_UUID_TOKEN, PERM(NTF, ENABLE)|PERM(WR, ENABLE), MIBLE_CHAR_LEN_TOKEN,
                                                    0, NULL},
    /// Token Characteristic - Client Char. Configuration Descriptor
    [MIBLE_IDX_TOKEN_NTF_CFG]                   =   {ATT_DESC_CLIENT_CHAR_CFG, PERM(RD, ENABLE)|PERM(WR, ENABLE), sizeof(uint16_t),
                                                    0, NULL},
    
    /// Token Characteristic Declaration
    [MIBLE_IDX_PRODUCT_ID_CHAR]       =   {ATT_DECL_CHARACTERISTIC, PERM(RD, ENABLE), sizeof(mible_product_id_char),
                                                 sizeof(mible_product_id_char), (uint8_t *)&mible_product_id_char},
    /// Token Characteristic Value
    [MIBLE_IDX_PRODUCT_ID_VAL]        =   {MIBLE_CHAR_UUID_PRODUCTID, PERM(RD, ENABLE), MIBLE_CHAR_LEN_PRODUCTID,
                                                 0, NULL},

    /// Supported Unread Alert Category Characteristic Declaration
    [MIBLE_IDX_VERSION_CHAR]    =   {ATT_DECL_CHARACTERISTIC, PERM(RD, ENABLE), sizeof(mible_version_char),
                                                 sizeof(mible_version_char), (uint8_t *)&mible_version_char},
    /// Supported New Alert Category Characteristic Value
    [MIBLE_IDX_VERSION_VAL]     =   {MIBLE_CHAR_UUID_VERSION, PERM(RD, ENABLE), MIBLE_CHAR_LEN_VERSION,
                                                 0, NULL},

    /// Unread Alert Status Characteristic Declaration
    [MIBLE_IDX_WIFI_CFG_CHAR]      =   {ATT_DECL_CHARACTERISTIC, PERM(RD, ENABLE), sizeof(mible_wifi_cfg_char),
                                                 sizeof(mible_wifi_cfg_char), (uint8_t *)&mible_wifi_cfg_char},
    /// Unread Alert Status Characteristic Value
    [MIBLE_IDX_WIFI_CFG_VAL]       =   {MIBLE_CHAR_UUID_WIFICFG, PERM(NTF, ENABLE)|PERM(WR, ENABLE), MIBLE_CHAR_LEN_WIFICFG,
                                                 0, NULL},
    /// Unread Alert Status Characteristic - Client Char. Configuration Descriptor
    [MIBLE_IDX_WIFI_CFG_NTF_CFG]       =   {ATT_DESC_CLIENT_CHAR_CFG, PERM(RD, ENABLE)|PERM(WR, ENABLE), sizeof(uint16_t),
                                                 0, NULL},
    
    // Authentication Characteristic Declaration
    [MIBLE_IDX_AUTHEN_CHAR]                 =   {ATT_DECL_CHARACTERISTIC, PERM(RD, ENABLE), sizeof(mible_authen_char),
                                                sizeof(mible_authen_char), (uint8_t *)&mible_authen_char},
    // Authentication Characteristic Value
    [MIBLE_IDX_AUTHEN_VAL]                  =   {MIBLE_CHAR_UUID_AUTHENTICATION, PERM(WR, ENABLE), MIBLE_CHAR_LEN_AUTHENTICATION,
                                                0, NULL},
    
    // DID Characteristic Declaration
    [MIBLE_IDX_DID_CHAR]                    =   {ATT_DECL_CHARACTERISTIC, PERM(RD, ENABLE), sizeof(mible_did_char),
                                                sizeof(mible_did_char), (uint8_t *)&mible_did_char},
    // DID Characteristic Value
    [MIBLE_IDX_DID_VAL]                     =   {MIBLE_CHAR_UUID_DID, PERM(RD, ENABLE) | PERM(WR, ENABLE), MIBLE_CHAR_LEN_DID,
                                                0, NULL},
    
    // Beaconkey Characteristic Declaration
    [MIBLE_IDX_BEACONKEY_CHAR]              =   {ATT_DECL_CHARACTERISTIC, PERM(RD, ENABLE), sizeof(mible_beaconkey_char),
                                                sizeof(mible_beaconkey_char), (uint8_t *)&mible_beaconkey_char},
    // DID Characteristic Value
    [MIBLE_IDX_BEACONKEY_VAL]               =   {MIBLE_CHAR_UUID_BEACONKEY, PERM(RD, ENABLE), MIBLE_CHAR_LEN_BEACONKEY,
                                                0, NULL}, 
};

/*
 * GLOBAL VARIABLE DEFINITIONS
 ****************************************************************************************
 */

/// Mible Profile Server Environment Variable
struct mis_env_tag mis_env;
/// Mible Profile Server Pool of Environments
struct mis_idx_env_tag **mis_idx_envs;

/*
 * FUNCTION DEFINITIONS
 ****************************************************************************************
 */

void mis_init(void)
{
    // Reset Common Environment
    memset(&mis_env, 0, sizeof(mis_env));

    // Register MIBLE task into kernel
    task_mis_desc_register();

    // Reset all environments
    prf_client_reset((prf_env_struct ***)&mis_idx_envs, TASK_MIS, MIS_DISABLED);

    // First instance goes to IDLE state
    ke_state_set(TASK_MIS, MIS_DISABLED);
}

void mis_send_cmp_evt(ke_task_id_t src_id, ke_task_id_t dest_id, uint16_t conhdl,
                       uint8_t operation, uint8_t status)
{
    // Come back to the Connected state if the state was busy.
    if (ke_state_get(src_id) == MIS_BUSY)
    {
        ke_state_set(src_id, MIS_CONNECTED);
    }

    // Send the message to the application
    struct mis_cmp_evt *evt = KE_MSG_ALLOC(MIS_CMP_EVT,
                                            dest_id, src_id,
                                            mis_cmp_evt);

    evt->conhdl      = conhdl;
    evt->operation   = operation;
    evt->status      = status;

    ke_msg_send(evt);
}

void mis_disable(struct mis_idx_env_tag *mis_idx_env)
{
    // Disable ANS
    attsdb_svc_set_permission(mis_env.mis_shdl, PERM(SVC, DISABLE));

    // Send Configuration
    struct mis_disable_ind *ind = KE_MSG_ALLOC(MIS_DISABLE_IND,
                                                mis_idx_env->con_info.appid, mis_idx_env->con_info.prf_id,
                                                mis_disable_ind);

    ind->conhdl                      = mis_idx_env->con_info.conhdl;

    ke_msg_send(ind);

    // Remove the connection environment
    prf_client_disable((prf_env_struct ***)&mis_idx_envs, KE_IDX_GET(mis_idx_env->con_info.prf_id));

    // Go to Idle state
    ke_state_set(mis_idx_env->con_info.prf_id, MIS_IDLE);
}

#endif //(BLE_MIS_SERVER)

/// @} MIS
