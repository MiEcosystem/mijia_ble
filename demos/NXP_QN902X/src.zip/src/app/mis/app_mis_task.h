/**
 ****************************************************************************************
 *
 * @file app_mis_task.h
 *
 * @brief Application MIS implementation
 *
 * Copyright(C) 2015 NXP Semiconductors N.V.
 * All rights reserved.
 *
 * $Rev: 1.0 $
 *
 ****************************************************************************************
 */

#ifndef APP_MIS_TASK_H_
#define APP_MIS_TASK_H_

/**
 ****************************************************************************************
 * @addtogroup APP_MIS_TASK Mible Server Task API
 * @ingroup APP_MIS
 * @brief Mible Server Task API
 *
 * Mible Server Task APIs are used to handle the message from TASK_MIS or APP.
 *
 * @{
 ****************************************************************************************
 */

#if BLE_MIS_SERVER

/*
 * INCLUDE FILES
 ****************************************************************************************
 */
#include "app_mis.h"

/// @cond

/// Mible Server environment variable
struct app_mis_env_tag
{
    /// Profile role state: enabled/disabled
    uint8_t enabled;
    /// Connection handle
    uint16_t conhdl;
};


/*
 * GLOBAL VARIABLE DEFINITIONS
 ****************************************************************************************
 */
extern struct app_mis_env_tag *app_mis_env;

/*
 * TYPE DEFINITIONS
 ****************************************************************************************
 */

/// @endcond

/*
 * FUNCTION DECLARATIONS
 ****************************************************************************************
 */

/*
 ****************************************************************************************
 * @brief Handles the disable service indication from the MIS.
 *
 ****************************************************************************************
 */
int app_mis_disable_ind_handler(ke_msg_id_t const msgid,
                                 struct mis_disable_ind *param,
                                 ke_task_id_t const dest_id,
                                 ke_task_id_t const src_id);


/*
 ****************************************************************************************
 * @brief Handles Complete Event Information .
 *
 ****************************************************************************************
 */
int app_mis_cmp_evt_handler(ke_msg_id_t const msgid,
                             struct mis_cmp_evt *param,
                             ke_task_id_t const dest_id,
                             ke_task_id_t const src_id);
#endif // BLE_MIS_SERVER

/// @} APP_MIS_TASK

#endif // APP_MIS_TASK_H_
