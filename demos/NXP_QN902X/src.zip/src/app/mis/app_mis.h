/**
 ****************************************************************************************
 *
 * @file app_mis.h
 *
 * @brief Application MIS API
 *
 * Copyright(C) 2015 NXP Semiconductors N.V.
 * All rights reserved.
 *
 * $Rev: 1.0 $
 *
 ****************************************************************************************
 */

#ifndef APP_MIS_H_
#define APP_MIS_H_

/**
 ****************************************************************************************
 * @addtogroup APP_MIS_API Mible 'Profile' Server
 * @ingroup APP_MIS
 * @brief Mible 'Profile' Server
 *
 * @{
 ****************************************************************************************
 */

/*
 * INCLUDE FILES
 ****************************************************************************************
 */

#if BLE_MIS_SERVER
#include "mis.h"
#include "mis_task.h"
#include "app_mis_task.h"

/*
 * FUNCTION DECLARATIONS
 ****************************************************************************************
 */

/*
 ****************************************************************************************
 * @brief Generic message to read characteristic
 *
 ****************************************************************************************
 */
void app_mis_create_db(void);

/*
 ****************************************************************************************
 * @brief Start the Mible Profile server role
 *
 ****************************************************************************************
 */
void app_mis_enable_req(uint8_t conhdl, uint8_t sec_lvl, uint8_t con_type);

#endif // BLE_MIS_SERVER

/// @} APP_MIS_API

#endif // APP_MIS_H_
