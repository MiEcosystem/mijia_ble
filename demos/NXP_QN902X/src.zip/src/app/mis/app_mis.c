/**
 ****************************************************************************************
 *
 * @file app_mis.c
 *
 * @brief Application MIS API
 *
 * Copyright(C) 2015 NXP Semiconductors N.V.
 * All rights reserved.
 *
 * $Rev: 1.0 $
 *
 ****************************************************************************************
 */

/**
 ****************************************************************************************
 * @addtogroup APP_MIS_API
 * @{
 ****************************************************************************************
 */

/*
 * INCLUDE FILES
 ****************************************************************************************
 */
 
#include "app_env.h"

#if BLE_MIS_SERVER
#include "app_mis.h"

/*
 * TYPE DEFINITIONS
 ****************************************************************************************
 */

/*
 * DEFINES
 ****************************************************************************************
 */

/*
 * MACROS
 ****************************************************************************************
 */

 /*
 ****************************************************************************************
 * @brief Create the Mible Profile server database - at initiation  *//**
 * 
 * @response  MIS_CMP_EVT
 * @description
 *
 * This API message shall be used to add one instance of the Mible Service 
 * in the database.
 * 
 ****************************************************************************************
 */
void app_mis_create_db(void)
{
    struct mis_create_db_req *msg = KE_MSG_ALLOC(MIS_CREATE_DB_REQ, TASK_MIS, TASK_APP,
                                                  mis_create_db_req);

    // Send the message
    ke_msg_send(msg);
}

 /*
 ****************************************************************************************
 * @brief Start the Mible Profile server role - at connection        *//**
 * 
 * @param[in] conhdl    Connection handle for which the Mible Profile Server 
 *                      role is enabled.
 * @param[in] sec_lvl             Required security level.
 * - PERM_RIGHT_ENABLE
 * - PERM_RIGHT_UNAUTH
 * - PERM_RIGHT_AUTH
 * @param[in] con_type            Connection Type:configuration(0) or discovery(1)
 * @response  MIS_CMP_EVT
 * @description
 *
 * This API message shall be used after the connection with a peer device has been established
 * in order to enable the ANP Server role task for the specified connection. 
 * 
 * Application shall provide connection handle in order to activate the profile. Connection 
 * handle and Application task ID are saved within the role's environment.
 * 
 * Connection Type will determine if notification configurations should be applied to the 
 * corresponding MIS Attributes in the database:
 *     - Normal connection: Peer device is known (bonded) and client configuration characteristics
 *       values shall  be restored. 
 *     - Discovery connection: Peer device is unknown and peer collector will manage client
 *       configuration characteristics.
 * The security level is very important because it allows the application to modulate the 
 * protection of the attributes related to the profile. The implementation only allows modulation
 * of the read/write/notify permissions (!not properties) of the characteristic values. (if 
 * unauthenticated is requested, then a Read/Write to a characteristic won't be allowed if the 
 * link between the devices is not unauthenticated level of security. 
 ****************************************************************************************
 */
void app_mis_enable_req( uint8_t conhdl, uint8_t sec_lvl, uint8_t con_type)
{
    struct mis_enable_req *msg = KE_MSG_ALLOC(MIS_ENABLE_REQ, KE_BUILD_ID(TASK_MIS, conhdl), TASK_APP,
                                                mis_enable_req);

    msg->conhdl = conhdl;
    msg->sec_lvl = sec_lvl;
    msg->con_type = con_type;

    // Send the message
    ke_msg_send(msg);
}


#endif // BLE_MIS_SERVER

/// @} APP_MIS_API
