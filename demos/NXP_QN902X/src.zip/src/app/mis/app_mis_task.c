/**
 ****************************************************************************************
 *
 * @file app_mis_task.c
 *
 * @brief Application MIS implementation
 *
 * Copyright(C) 2015 NXP Semiconductors N.V.
 * All rights reserved.
 *
 * $Rev: 1.0 $
 *
 ****************************************************************************************
 */

/**
 ****************************************************************************************
 * @addtogroup APP_MIS_TASK
 * @{
 ****************************************************************************************
 */

/*
 * INCLUDE FILES
 ****************************************************************************************
 */

#include "app_env.h"
#include "mible_type.h"

#if BLE_MIS_SERVER
#include "app_mis.h"

/// @cond
/*
 * GLOBAL VARIABLE DEFINITIONS
 ****************************************************************************************
 */
struct app_mis_env_tag *app_mis_env = &app_env.mis_ev;

/// @endcond

/*
 * FUNCTION DEFINITIONS
 ****************************************************************************************
 */

/*
 ****************************************************************************************
 * @brief Handles the disable service indication from the MIS.     *//**
 *
 * @param[in] msgid     MIS_DISABLE_IND
 * @param[in] param     Pointer to the struct mis_disable_ind
 * @param[in] dest_id   TASK_APP
 * @param[in] src_id    TASK_MIS
 *
 * @return If the message was consumed or not.
 * @description
 *
 * This handler is used by the MIS Server role to inform the application of a correct
 * disable after a disconnection.
 * 
 ****************************************************************************************
 */
int app_mis_disable_ind_handler(ke_msg_id_t const msgid,
                                 struct mis_disable_ind *param,
                                 ke_task_id_t const dest_id,
                                 ke_task_id_t const src_id)
{
    app_mis_env->conhdl = 0xFFFF;
    app_mis_env->enabled = false;
    
    app_task_msg_hdl(msgid, param);

    return (KE_MSG_CONSUMED);
}


/*
 ****************************************************************************************
 * @brief Handles Complete Event Information.       *//**
 *
 * @param[in] msgid     MIS_CMP_EVT
 * @param[in] param     Pointer to the struct mis_cmp_evt
 * @param[in] dest_id   TASK_APP
 * @param[in] src_id    TASK_MIS
 *
 * @return If the message was consumed or not.
 * @description
 * 
 * The handler is used by the MIS task to inform the sender of a command that the procedure
 * is over and contains the status of the procedure. 
 ****************************************************************************************
 */
int app_mis_cmp_evt_handler(ke_msg_id_t const msgid,
                             struct mis_cmp_evt *param,
                             ke_task_id_t const dest_id,
                             ke_task_id_t const src_id)
{
    if (param->status == CO_ERROR_NO_ERROR)
    {
        switch (param->operation)
        {
            case MIS_CREATE_DB_OP_CODE:
                if (param->status == ATT_ERR_NO_ERROR)
                {
                    app_clear_local_service_flag(BLE_MIS_SERVER_BIT);
                }
                break;
            case MIS_ENABLE_OP_CODE:
                break;
            default:
                break;
        }
    }
    
    app_task_msg_hdl(msgid, param);

    return (KE_MSG_CONSUMED);
}
#endif // BLE_MIS_SERVER

/// @} APP_MIS_TASK
